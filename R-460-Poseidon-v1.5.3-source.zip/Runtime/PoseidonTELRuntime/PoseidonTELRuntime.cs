using System;
using System.Collections.Generic;
using BepInEx;
using HarmonyLib;
using UnityEngine;

namespace PoseidonTELRuntime
{
    [BepInPlugin(PluginId, "R-460 Poseidon TEL Targeting", "1.4.4")]
    public sealed class PoseidonTELRuntime : BaseUnityPlugin
    {
        private const string PluginId = "ua.ncmod.poseidon.tel-targeting";
        private const string LauncherKey = "R460_Poseidon_TEL";
        private const float MaxRangeMeters = 108000f;
        private const float MaxTrackAgeSeconds = 45f;

        private void Awake()
        {
            var targetSearch = AccessTools.Method(
                typeof(FactionHQ),
                nameof(FactionHQ.GetTargetsWithinRange),
                new[] { typeof(List<TrackingInfo>), typeof(Transform), typeof(float), typeof(bool) });
            var filter = AccessTools.Method(typeof(PoseidonTELRuntime), nameof(FilterPoseidonTargets));
            if (targetSearch == null || filter == null)
            {
                Logger.LogError("Could not attach the R-460 TEL naval target filter.");
                return;
            }

            new Harmony(PluginId).Patch(targetSearch, postfix: new HarmonyMethod(filter));
            Logger.LogInfo("R-460 TEL naval targeting enabled (108 km). Pure vertical launch enabled.");
        }

        private static void FilterPoseidonTargets(FactionHQ __instance, Transform fromTransform,
            bool requireLineOfSight, List<TrackingInfo> __result)
        {
            if (__instance == null || fromTransform == null || __result == null)
                return;

            var launcher = fromTransform.GetComponent<GroundVehicle>();
            if (launcher == null || launcher.definition == null || launcher.definition.jsonKey != LauncherKey)
                return;

            var launchPosition = launcher.GlobalPosition();
            __result.Clear();
            foreach (var track in __instance.trackingDatabase.Values)
            {
                Unit target;
                if (track == null || !track.TryGetUnit(out target) || !(target is Ship) ||
                    target.disabled || target.NetworkHQ == null || target.NetworkHQ == __instance ||
                    Time.timeSinceLevelLoad - track.lastSpottedTime > MaxTrackAgeSeconds ||
                    !FastMath.InRange(launchPosition, track.GetPosition(), MaxRangeMeters) ||
                    (requireLineOfSight && !target.LineOfSight(fromTransform.position, 1000f)))
                    continue;

                __result.Add(track);
            }
        }
    }
}
