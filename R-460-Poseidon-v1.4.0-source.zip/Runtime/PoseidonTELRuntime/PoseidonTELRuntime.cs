using System;
using System.Collections.Generic;
using BepInEx;
using HarmonyLib;
using UnityEngine;

namespace PoseidonTELRuntime
{
    [BepInPlugin(PluginId, "R-460 Poseidon TEL Targeting", "1.4.0")]
    public sealed class PoseidonTELRuntime : BaseUnityPlugin
    {
        private const string PluginId = "ua.ncmod.poseidon.tel-targeting";
        private const string LauncherKey = "R460_Poseidon_TEL";
        private const float MaxRangeMeters = 108000f;

        private void Awake()
        {
            var targetSearch = AccessTools.Method(
                typeof(FactionHQ),
                nameof(FactionHQ.GetTargetsWithinRange),
                new[] { typeof(List<TrackingInfo>), typeof(Transform), typeof(float), typeof(bool) });
            var filter = AccessTools.Method(typeof(PoseidonTELRuntime), nameof(FilterPoseidonTargets));
            if (targetSearch == null || filter == null)
            {
                Logger.LogError("Could not attach the R-460 TEL naval target filter.");
                return;
            }

            new Harmony(PluginId).Patch(targetSearch, postfix: new HarmonyMethod(filter));
            Logger.LogInfo("R-460 TEL naval targeting enabled (108 km).");
        }

        private static void FilterPoseidonTargets(Transform fromTransform, List<TrackingInfo> __result)
        {
            if (fromTransform == null || __result == null)
                return;

            var launcher = fromTransform.GetComponent<GroundVehicle>();
            if (launcher == null || launcher.definition == null || launcher.definition.jsonKey != LauncherKey)
                return;

            for (var i = __result.Count - 1; i >= 0; i--)
            {
                Unit target;
                if (!__result[i].TryGetUnit(out target) ||
                    !(target is Ship) ||
                    !FastMath.InRange(launcher.GlobalPosition(), target.GlobalPosition(), MaxRangeMeters))
                {
                    __result.RemoveAt(i);
                }
            }
        }
    }
}
